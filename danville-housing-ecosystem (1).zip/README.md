# Danville Housing Ecosystem

A practical starter repo for launching your housing ecosystem in Danville:
- **Lender + Flipper + Supply + Nonprofit (repair program)**
- Includes: business plan, pitch outline, first flip worksheet, and software toolkit.

## Structure
```
danville-housing-ecosystem/
├─ README.md
├─ LICENSE
├─ docs/
│  ├─ business_plan_outline.md
│  ├─ investor_pitch_deck.md
│  ├─ funding_targets.md
│  ├─ Business_Plan_Outline.docx
│  ├─ First_Flip_Worksheet.docx
│  └─ Starter_Software_Toolkit.pdf
└─ templates/
   ├─ one_pager.docx
   └─ investor_email_template.txt
```

## Quick Start
1) Download this repo zip and extract it
2) Create a new GitHub repo (public or private)
3) In the extracted folder, run:
```bash
git init
git add .
git commit -m "Initial commit: Danville Housing Ecosystem"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
git push -u origin main
```

## How to Use
- **/docs/business_plan_outline.md** – full plan you can refine.
- **/docs/investor_pitch_deck.md** – slide-by-slide script to present.
- **/docs/funding_targets.md** – who to pitch + how.
- **/docs/First_Flip_Worksheet.docx** – fill out for your home pilot.
- **/docs/Starter_Software_Toolkit.pdf** – design + planning tools.
- **/templates/one_pager.docx** – a one-page summary for meetings.
- **/templates/investor_email_template.txt** – cold/warm outreach draft.

> Legal note: This repo contains business planning materials and is **not legal or financial advice**. Customize and review with licensed pros where needed.
