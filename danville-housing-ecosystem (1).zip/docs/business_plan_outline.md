# Business Plan Outline — Danville Housing Ecosystem

## 1) Executive Summary
- **Vision:** Create a housing ecosystem in Danville combining lending, flipping, supplies, and a nonprofit repair initiative.
- **Mission:** Revitalize neighborhoods, empower families, and generate wealth through real estate.
- **Pilot:** Flip my own home as proof-of-concept to demonstrate ROI + impact.

## 2) Company Overview
- **Parent:** Seraphina Soulworks LLC (holding company).
- **Arms:**
  - Mortgage Lender (financing/education)
  - House Flipping (buy, rehab, sell/rent)
  - Supply Company (affordable materials)
  - Nonprofit Repair Program (community & veterans)

## 3) Market Analysis
- **Danville snapshot:** undervalued properties, aging stock, strong rental demand; room for revitalization.
- **Competition:** fragmented (lenders, contractors, suppliers operate separately).
- **Advantage:** integrated, community-first model.
- **Target customers:** families, veterans, first-time buyers, landlords, city contracts.

## 4) Services & Products
- Mortgage loans, refinancing, buyer education.
- Flipped homes and rentals.
- Building supplies & repair kits (wholesale + retail).
- Nonprofit repairs (grants/donations), workforce training.

## 5) Business Model & Revenue
- **Lender:** fees, origination points, commissions.
- **Flipping:** margin between acquisition + rehab + ARV (or BRRRR refi).
- **Supply:** inventory markup, bulk deals, liquidation arbitrage.
- **Nonprofit:** grants, donations, sponsorships.

## 6) Marketing & Sales
- Story-driven content (before/after, veteran-led).
- Partnerships with city, churches, credit unions.
- Community events via nonprofit = trust and deal flow.
- Investor breakfasts / open house demos.

## 7) Operations
- Phase 1: Flip my house; set up licenses; vendor/contractor list.
- Phase 2: 1–3 flips/yr; launch supply pilot; first nonprofit project.
- Phase 3: 5–10 flips/yr; supply warehouse; multi-year grant cycles.

## 8) Financial Plan
- **Startup:** $15–$30k pilot; $50–$140k full buildout.
- **Funding:** hard money, private investors, SBA microloans, vendor credit; HUD/CDBG grants for nonprofit.
- **Pro forma:** flip ROI (X%), rental cashflow, material sales projections.

## 9) Team
- Founder (vision, finance, veteran leadership).
- Youth advisory (daughters) for storytelling & community lens.
- Nonprofit board (local leaders).
- Realtor, GC, subs, suppliers.

## 10) Risk & Compliance
- Licensing, permits, insurance, construction risk buffers.
- Conservative ARV, 10–15% contingency on rehab.
- Separate books for for‑profit and nonprofit arms.
