# Funding Targets & Outreach

## For‑Profit (Investment / Credit)
- Local real estate investors
- Private lenders / hard money lenders
- Veteran investor networks
- Community banks & credit unions (CRA projects)
- Supplier/vendor credit (Home Depot Pro, Grainger, Uline)

**Offer:** profit share per flip, equity in supply arm, or secured notes.

## Nonprofit (Grants / Donations)
- City/HUD: CDBG, housing repair programs
- Federal Home Loan Bank AHP
- Veterans home repair grants
- Corporate sponsors (Lowe’s, Home Depot, Walmart)
- Churches & civic groups

**Offer:** tax-deductible contributions, visibility/PR, community impact metrics.

## Hybrid Partners
- Mayor/city council, Chamber of Commerce, CDCs
- Workforce boards (training/apprenticeships)
- Local colleges/trade schools

---

## Outreach Scripts

### Warm Intro (Investor)
“Hi [Name], I’m building a housing ecosystem in Danville and using my own home as the pilot flip. I’d value your perspective on the model and would love to discuss a partner role on the pilot ($25–$50k, profit share per flip). Can we schedule a 20‑minute walk-through this week?”

### Bank/CU (CRA-Aligned)
“Hi [Banker], I’m a veteran-led startup integrating lending, renovation, materials, and nonprofit repairs in Danville. We’re seeking a CRA‑friendly partnership on a pilot flip plus a repair program for low‑income veterans. Can we meet to explore underwriting and community impact alignment?”

### Corporate Sponsor
“Hi [Sponsor], we’re launching a nonprofit home repair pilot in Danville and would like [Company] to be the title sponsor for materials and tools. In return, we’ll provide press, logo placements, and community event visibility.”
