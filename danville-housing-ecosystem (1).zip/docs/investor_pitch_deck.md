# Investor Pitch — Danville Housing Ecosystem

## Slide 1 — Title & Story
Veteran, single mom, community builder. **Pilot flip = my own home**. Building a lender + flipper + supply + nonprofit ecosystem in Danville.

## Slide 2 — The Problem
Aging homes, limited repair help, families stuck renting, fragmented services.

## Slide 3 — The Solution
One integrated model: **Finance it (lender) → Fix it (flips) → Supply it (materials) → Support it (nonprofit).**

## Slide 4 — Market Opportunity (Danville)
Undervalued homes, strong rental demand, need for revitalization. First‑mover advantage as an integrated provider.

## Slide 5 — Business Model
Multiple revenue streams: lender fees, flip margins, supply sales, grants/sponsorships.

## Slide 6 — Pilot: My Home
Scope, budget, timeline. Before/after plan. How we’ll measure success (ARV, time-to-complete, documentation).

## Slide 7 — Financials & Projections
- Pilot rehab budget & ARV
- Year 1–2: # of flips, expected ROI, supply sales targets
- Nonprofit: # of homes aided, grants pursued

## Slide 8 — Traction & Assets
- Business plan, toolkit, flip worksheet
- Vendor/contractor pipeline in progress
- Community relationships

## Slide 9 — Impact
Jobs, training, veteran service, neighborhood uplift. A dollar that *stays* in Danville.

## Slide 10 — The Ask
**$25k–$50k** seed (or equivalent in credit/in-kind materials). Use of funds: rehab, legal/licensing, marketing.

## Slide 11 — Returns / Partnerships
- Profit share per flip OR equity in supply arm
- Visibility on nonprofit projects (naming rights / PR)
- CRA-aligned partnerships for banks/credit unions

## Slide 12 — Next Steps
Join the pilot flip, site walk-through, due diligence data room, close funding.
